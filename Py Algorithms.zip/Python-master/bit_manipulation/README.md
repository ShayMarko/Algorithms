https://docs.python.org/3/reference/expressions.html#binary-bitwise-operations
https://docs.python.org/3/reference/expressions.html#unary-arithmetic-and-bitwise-operations
https://docs.python.org/3/library/stdtypes.html#bitwise-operations-on-integer-types

https://wiki.python.org/moin/BitManipulation
https://wiki.python.org/moin/BitwiseOperators
https://www.tutorialspoint.com/python3/bitwise_operators_example.htm
