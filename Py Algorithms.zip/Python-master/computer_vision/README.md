### Computer Vision

Computer vision is a field of computer science that works on enabling computers to see,
identify and process images in the same way that human vision does, and then provide appropriate output.
It is like imparting human intelligence and instincts to a computer.
Image processing and computer vision and little different from each other.Image processing means applying some algorithms for transforming image from one form to other like smoothing,contrasting, stretching etc
While in computer vision comes from modelling image processing using the techniques of machine learning.Computer vision applies machine learning to recognize patterns for interpretation of images.
Much like the process of visual reasoning of human vision
