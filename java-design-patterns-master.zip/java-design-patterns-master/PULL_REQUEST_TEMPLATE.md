
Pull request title

- Clearly and concisely describes what it does
- Refer to the issue that it solves, if available


Pull request description

- Describes the main changes that come with the pull request
- Any relevant additional information is provided



> For detailed contributing instructions see https://github.com/iluwatar/java-design-patterns/wiki/01.-How-to-contribute
